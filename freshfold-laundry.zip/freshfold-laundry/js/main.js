// FreshFold Laundry – interactions
(function(){
  var menuBtn=document.getElementById('ff-menubtn'), menu=document.getElementById('ff-menu'), path=menuBtn.querySelector('path');
  function setMenu(open){menu.classList.toggle('ff-open',open);menuBtn.setAttribute('aria-expanded',open?'true':'false');path.setAttribute('d',open?'M6 6l12 12M18 6L6 18':'M4 7h16M4 12h16M4 17h16');}
  menuBtn.addEventListener('click',function(){setMenu(!menu.classList.contains('ff-open'));});
  menu.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(){setMenu(false);});});
  var chips=document.querySelectorAll('.ff-chip'), names=["Wash & fold", "Dry cleaning", "Steam ironing", "Shoe cleaning", "Carpet cleaning", "Curtain cleaning"], picked=0;
  chips.forEach(function(b){b.addEventListener('click',function(){picked=+b.dataset.i;chips.forEach(function(c,i){var on=i===picked;c.setAttribute('aria-pressed',on?'true':'false');c.style.cssText=on?"min-height: 44px; padding: 0 16px; border-radius: 999px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all .2s ease; background: #0B6770; color: #FFFFFF; border: 1px solid #0B6770":"min-height: 44px; padding: 0 16px; border-radius: 999px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all .2s ease; background: #FFFFFF; color: #10263A; border: 1px solid #C8D5DE";});});});
  var form=document.getElementById('ff-form'), wrap=document.getElementById('ff-form-wrap'), done=document.getElementById('ff-done');
  form.addEventListener('submit',function(e){e.preventDefault();document.getElementById('ff-svcname').textContent=names[picked].toLowerCase();wrap.hidden=true;done.hidden=false;});
  document.getElementById('ff-again').addEventListener('click',function(){form.reset();done.hidden=true;wrap.hidden=false;});
  var faqs=document.querySelectorAll('.ff-faqbtn');
  faqs.forEach(function(btn){btn.addEventListener('click',function(){var wasOpen=btn.getAttribute('aria-expanded')==='true';
    faqs.forEach(function(b){var open=(b===btn)&&!wasOpen;b.setAttribute('aria-expanded',open?'true':'false');
      var box=b.closest('.ff-reveal');box.style.cssText=open?"border-radius: 16px; transition: all .3s ease; background: #FFFFFF; border: 1px solid #8FD3D9; box-shadow: 0 14px 30px rgba(16,38,58,.08)":"border-radius: 16px; transition: all .3s ease; background: #F7F9FA; border: 1px solid #E3E9EE";
      b.querySelector('span[aria-hidden]').style.cssText=open?"flex-shrink: 0; width: 34px; height: 34px; border-radius: 999px; display: flex; align-items: center; justify-content: center; transition: transform .3s ease; background: #0B6770; color: #FFFFFF; transform: rotate(45deg)":"flex-shrink: 0; width: 34px; height: 34px; border-radius: 999px; display: flex; align-items: center; justify-content: center; transition: transform .3s ease; background: #EEF6F7; color: #0B6770";
      document.getElementById(b.getAttribute('aria-controls')).hidden=!open;});});});
})();
